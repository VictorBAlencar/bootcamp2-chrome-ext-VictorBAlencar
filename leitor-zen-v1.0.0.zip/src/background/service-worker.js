chrome.runtime.onInstalled.addListener(() => {
  console.log('Extensão Leitor Zen instalada com sucesso.');
  
});